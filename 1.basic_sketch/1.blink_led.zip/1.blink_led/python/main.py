import time
from arduino.app_utils import App

RED = "/sys/class/leds/red:user/brightness"

def set_led(value):
    with open(RED, "w") as f:
        f.write(str(value))

def loop():
    set_led(1)   # ON
    time.sleep(1)

    set_led(0)   # OFF
    time.sleep(1)

App.run(user_loop=loop)